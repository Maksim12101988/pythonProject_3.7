from .base_page import BasePage
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver import Keys




class SkillboxPage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

    def open_catalog(self):
        catalog_button = self.wait_for_element((By.XPATH, "/html/body/div[1]/div/div/header/div[1]/div/button"))
        catalog_button.click()

    def perform_search(self, query):
        search_input = self.wait_for_element((By.XPATH, "/html/body/div[1]/div/div/header/div[1]/div/div/div/div[1]/label/input"))
        search_input.send_keys(query, Keys.RETURN)

    def select_difficulty(self):
        difficulty_button = self.wait_for_element((By.XPATH, "/html/body/div[1]/div/div/main/div[1]/div[2]/div/div[1]/div[1]/div[3]/ul/li[2]/label/span"))
        difficulty_button.click()

    def click_course_card(self):
        course_card = self.wait_for_element((By.XPATH, "//article[2]/div/a"))
        self.execute_script("arguments[0].click();", course_card)

    def switch_to_new_tab(self):
        try:
            WebDriverWait(self.driver, 10).until(EC.new_window_is_opened)
            windows = self.driver.window_handles
            self.driver.switch_to.window(windows[-1])
        except Exception as e:
            print(f"Ошибка при переключении на новую вкладку: {str(e)}")

    def verify_course_page(self):
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "body > main > section:nth-child(2) p")))
        element_text = self.driver.find_element(By.CSS_SELECTOR, "body > main > section:nth-child(2) p").text.strip()
        assert "Компании нанимают QA-инженеров, которые умеют автоматизировать тестирование новых фич и быстрее доставлять их до пользователя без багов." in element_text, f"Ожидаемый текст не найден"

    def get_current_url(self):
        return self.driver.current_url
