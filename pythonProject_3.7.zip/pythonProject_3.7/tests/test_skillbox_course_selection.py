import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from steps.skillbox_steps import SkillboxSteps

@pytest.fixture(scope="function")
def setup():
    chrome_options = Options()
    chrome_options.add_argument('--start-maximized')
    chrome_options.add_argument('disable-notifications')
    chrome_options.add_argument('disable-infobars')

    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)
    yield driver
    driver.quit()


def test_skillbox_course_selection(setup):
    skillbox_steps = SkillboxSteps(setup)

    # Открываем сайт Skillbox
    setup.get("https://skillbox.ru/")

    # Выполняем шаги
    skillbox_steps.open_catalog()
    skillbox_steps.perform_search("автотесты на Python")
    skillbox_steps.select_difficulty()
    skillbox_steps.click_course_card()
    skillbox_steps.switch_to_new_tab()
    skillbox_steps.verify_course_page()
