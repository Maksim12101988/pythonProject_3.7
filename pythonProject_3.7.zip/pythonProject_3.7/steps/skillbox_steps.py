from .base_step import BaseStep
from pages.skillbox_page import SkillboxPage

class SkillboxSteps(BaseStep):
    def __init__(self, driver):
        super().__init__(driver)
        self.page = SkillboxPage(driver)

    def open_catalog(self):
        self.page.open_catalog()

    def perform_search(self, query):
        self.page.perform_search(query)

    def select_difficulty(self):
        self.page.select_difficulty()

    def click_course_card(self):
        self.page.click_course_card()

    def switch_to_new_tab(self):
        self.page.switch_to_new_tab()

    def verify_course_page(self):
        self.page.verify_course_page()

    def get_current_url(self):
        return self.page.get_current_url()
